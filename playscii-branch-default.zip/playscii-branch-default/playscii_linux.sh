python3 playscii.py "$1" "$2" "$3" "$4"

