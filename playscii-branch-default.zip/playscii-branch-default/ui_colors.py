
class UIColors:
    "color indices for UI (c64 original) palette"
    white = 2
    lightgrey = 16
    medgrey = 13
    darkgrey = 12
    black = 1
    yellow = 8
    red = 3
    brightred = 11
